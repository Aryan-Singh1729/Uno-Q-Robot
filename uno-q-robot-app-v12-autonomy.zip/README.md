# Optimus UNO Q autonomous voice robot - v12

This is one Arduino App Lab application containing both UNO Q processors:

- `python/main.py` launches microphone capture, transcription, autonomous tool calling,
  camera inspection, the live Web UI, and speech output on the Linux MPU.
- `sketch/sketch.ino` runs deterministic TB6612 motor control on the STM32 MCU.
- Arduino App Lab Bridge connects them. No SSH launch or separate Arduino upload is used.

## Observe-think-act mode

The HC-SR04, VL53L0X, MPU6050, and YDLIDAR X2 integrations are disabled as motion guards in
this build. Disconnected proximity sensors cannot block a command. Direct movement executes
immediately. Visual tasks alternate a fresh camera inspection with one short movement so the
agent can search, center a target, approach it, or move away from it. The MCU still stops if Python status
polling disappears for 750 ms, and `/stop` remains available as an emergency brake.

```text
microphone -> complete utterance -> Whisper transcript -> observe/plan
           -> inspect camera -> move/turn/spin -> inspect again
           -> spoken announcement -> Bridge RPC
           -> TB6612 motor outputs
```

## Hardware safety

- Raise the wheels for the first motor test.
- Power the motors from a suitable external motor supply, not the UNO Q 3.3 V rail.
- Join the motor-supply ground, both TB6612 grounds, and UNO Q ground.
- Tie both TB6612 `STBY` inputs to D2, as required by the sketch.
- Leave the X2 disconnected for this motor-only test.
- Keep a physical power disconnect within reach.

## App layout

```text
uno-q-robot/
|-- app.yaml
|-- python/
|   |-- main.py
|   `-- requirements.txt
|-- sketch/
|   |-- sketch.ino
|   `-- sketch.yaml
|-- main.py
|-- audio_io.py
|-- live_view.py
|-- assets/
|-- lidar_x2.py
|-- robot_agent.py
|-- execute_motion_bridge.py
|-- .env
`-- ...
```

The root modules are deployed with the app and can also be unit-tested on a development PC.

## Configuration

Create `.env` in the imported App Lab app and set your own keys. Never export or share it.

```env
GROQ_API_KEY=gsk_replace_me
DEEPGRAM_API_KEY=replace_me

ROBOT_NAME=Scout
LLM_MODEL=openai/gpt-oss-120b
VISION_MODEL=qwen/qwen3.6-27b
STT_MODEL=whisper-large-v3-turbo
DEEPGRAM_TTS_MODEL=aura-2-thalia-en
PLAYBACK_GAIN=1.4

CAMERA_INDEX=0
# MIC_DEVICE=0
# OUTPUT_DEVICE=1

# Proximity guards remain off even if an old LIDAR_REQUIRED=true line is present.
MOTION_GUARDS_ENABLED=false
# LIDAR_PORT=/dev/ttyUSB0
LIDAR_REQUIRED=false
LIDAR_FRONT_ANGLE_DEG=0
LIDAR_HALF_WIDTH_DEG=25
LIDAR_STOP_DISTANCE_MM=300
```

The LiDAR settings are retained for later experiments but are ignored while
`MOTION_GUARDS_ENABLED=false`.

## Import and run

1. Stop and delete the previous app so its build cache is not reused.
2. Import the newest ZIP from this repository.
3. Recreate `.env` with your private keys. You do not need to connect the LiDAR.
4. Connect the UNO Q, powered hub, EMEET SmartCam, and audio output.
5. Click **Run** once and let both sides finish building.
6. Confirm these messages appear:

```text
[MCU] autonomy-v12 Bridge ready
[MOTOR] UNO Q MCU bridge is ready
[WEB] live camera view ready; open the App Lab web button
[AUDIO] ... EMEET SmartCam ... -> selected
```

The Python app requires the exact `autonomy-v12` MCU handshake. If App Lab leaves an older
sensor sketch flashed, startup fails explicitly instead of silently using stale firmware.

For a direct test, keep the wheels raised and say:

```text
Move forward 5 centimeters at 50 percent speed.
```

Expected motion logs are:

```text
[PROPOSED] move(speed=50, distance=5)
[STATE] acting
[MOTOR] move started
[MOTOR] motion ... finished: completed
```

In this build a disconnected X2 does not appear at startup and cannot block movement. To
experimentally restore it later, set `MOTION_GUARDS_ENABLED=true`.

For an autonomous test, put the robot on a clear floor and say:

```text
Find a shoe in this room and move toward it.
```

The agent inspects a frame, turns in small increments while searching, and approaches in steps
of at most 20 cm with a new inspection between steps. A failed camera inspection prevents the
next autonomous movement. Open the globe/web button while the app runs to see the shared live
camera feed, task state, and emergency-stop button.

## Audio and camera behavior

Speech playback uses a 1.4 software gain (40% increase) by default. The app prefers
EMEET/SmartCam microphones over generic USB audio devices. Audio received at
48 kHz is resampled outside PortAudio's real-time callback to prevent input-overflow storms.
A short post-playback cooldown prevents the robot's own final spoken word from cancelling the
motion it just announced.

Vision tries each `/dev/video*` node if the configured camera opens but returns no frame. The
same camera object supplies both Qwen inspections and the Web UI feed, avoiding two processes
fighting over the USB camera.

## Controller envelope and calibration

- `move`: speed 1-100%, signed distance up to 1000 cm; positive is forward.
- `turn`: speed 1-100%, signed angle up to 3600 degrees; positive is left.
- `spin`: speed 1-100%, signed duration up to 120 seconds; positive is left.
- One autonomous voice task can use up to 30 motions or 10 minutes.

Those finite runtime bounds and the 750 ms MCU connection watchdog are failure containment,
not obstacle guards. `/stop`, new speech, the Web UI stop button, and physical power removal
can stop an active mission.

Motion remains open-loop because there are no wheel encoders. Measure the robot and update
`CM_PER_SEC_AT_100` and `DEG_PER_SEC_AT_100` in `sketch/sketch.ino`. If a wheel spins in the
wrong direction, change only its `*_POLARITY` constant from `1` to `-1`.

## Tests

```bash
python -m unittest discover -v
```

Desktop tests mock network, camera, audio, LiDAR data, and Bridge operations. Physical motion
is enabled only inside Arduino App Lab after the versioned MCU readiness RPC succeeds.
