# WALL-E UNO Q autonomous navigation — v17.0

This Arduino App Lab application runs both sides of the UNO Q from one **Run** button:

- Linux/Python: microphone, STT, camera, LLM tools, TTS, YDLIDAR X2 decoding,
  deterministic local navigation, and the live WebUI.
- STM32 sketch: TB6612 motor output, watchdog/braking, dual VL53L0X ranging,
  front ultrasonic ranging, MPU6050 heading correction, and hard real-time stops.
- Arduino RouterBridge: versioned RPC between the two processors.

The LLM only requests high-level timed movement. It does not receive a continuous raw
sensor stream and cannot bypass navigation. Obstacle and tilt actions happen before any
LLM or TTS response.

## Navigation architecture

```text
YDLIDAR X2 (primary, Linux USB serial) ----+
Left/right VL53L0X (MCU I2C) -------------+--> Navigation controller
Front ultrasonic (MCU GPIO) --------------+       |
MPU6050 (MCU I2C) ------------------------+       +--> Bridge motor calls --> TB6612 --> motors
                                                   +--> semantic events --> personality/WebUI
```

LiDAR supplies the 360-degree map, forward-path detection, free-side selection, corridor
centering, and local avoidance. Forward commands are executed in short independently
checked chunks. If the forward path is blocked, navigation stops, backs up when the rear
sector is clear, turns toward the clearer side, and resumes. Repeated failed recovery emits
`ROBOT_STUCK` and stops.

The two ToFs and ultrasonic sensor independently stop forward/unsafe turn motion at
**100 mm or closer** after two consecutive valid samples. MPU6050 stops all motion at
28 degrees of roll or pitch and applies bounded differential correction when a straight
drive drifts. The 750 ms MCU controller watchdog and 100 ms active brake remain enabled.

Only these semantic events are exposed to the LLM/tool result:

- `WALL_TOO_CLOSE`
- `OBSTACLE_DETECTED`
- `OBSTACLE_AVOIDING`
- `TILT_WARNING`
- `HEADING_CORRECTION`
- `PATH_BLOCKED`
- `ROBOT_STUCK`

Raw ranges remain available to the deterministic controller, `/sensors`, and the live
diagnostic page—not to the LLM prompt.

## Wiring added in v17

Both VL53L0X sensors and the MPU6050 share the UNO Q D20/D21 I2C bus.

| Device | Signal | UNO Q |
| --- | --- | --- |
| Left VL53L0X | SDA / SCL / XSHUT | D20 / D21 / D10 |
| Right VL53L0X | SDA / SCL / XSHUT | D20 / D21 / D11 |
| MPU6050 | SDA / SCL | D20 / D21 |
| Front ultrasonic | TRIG / ECHO | A3 / A4 |

Both ToFs are held in shutdown at boot. The sketch enables the left unit and assigns
`0x30`, then enables the right unit and assigns `0x31`. The MPU6050 remains at `0x68`.

Power the sensor breakouts from Buck #2 and join every sensor, driver, battery, and UNO Q
ground. **UNO Q GPIO is 3.3 V only. A raw 5 V HC-SR04 ECHO signal must pass through a
resistor divider or a proper logic-level shifter before A4.** Use 5 V on VL53L0X/MPU6050
only when the particular breakout board explicitly includes a regulator and I2C level
shifting; otherwise power it at its documented logic voltage.

The YDLIDAR X2 stays on its USB-to-UART/motor-control adapter connected to the UNO Q Linux
USB host. Do not move its UART to D0/D1: App Lab RouterBridge reserves `Serial1` there.

## Preserved motor implementation

v17 does not change the GPIO assignments, polarity constants, or final left/right semantic
correction that passed the v15/v16 physical floor tests:

| Physical output used by firmware | Wheel |
| --- | --- |
| Driver 1 A | front-left |
| Driver 1 B | rear-left |
| Driver 2 A | front-right |
| Driver 2 B | rear-right |

If the labels on the two rear driver output plugs say otherwise, do not change software
until tracing the actual wires: swapping those verified channel names would regress the
working forward, backward, left, and right truth table.

## Import and run

1. In Arduino App Lab, stop the older app and import
   `uno-q-robot-app-v17.0-autonomous-navigation.zip`.
2. Open the imported app's `.env` and add your own Groq and Deepgram keys. Never share it.
3. Connect the powered LiDAR USB adapter, camera, audio output, I2C sensors, ultrasonic,
   motor supply, and common ground.
4. Raise the wheels for the first test and keep a physical power disconnect within reach.
5. Click **Run**. App Lab installs the four Adafruit sketch libraries declared in
   `sketch/sketch.yaml`, flashes the MCU, and starts Python.
6. Confirm the console reports `navigation-v17.0`, a fresh X2 scan, and WebUI URL.

Healthy startup includes:

```text
[MCU] navigation-v17.0 Bridge ready; Serial1 reserved for RouterBridge
[MOTOR] UNO Q MCU bridge is ready
[NAV] LiDAR primary navigation and MCU supplemental guard configured at 10.0 cm
[LIDAR] opened YDLIDAR X2 serial port /dev/ttyUSB... at 115200 baud
[WEB] live camera + LiDAR view: http://arduinoq.local:7000
```

Run `/sensors` in the Python console. Verify both ToFs, ultrasonic, and MPU show ready and
plausible values before putting the wheels down. `/lidar` verifies scan freshness. Use
`/stop` or the red WebUI button for an immediate stop.

Open the Network URL printed by WebUI (normally `http://arduinoq.local:7000`). It displays
the camera, polar LiDAR scan, fixed red 10 cm boundary, nearest/front LiDAR distance, current
navigation event, both ToF distances, ultrasonic distance, roll/pitch, and emergency stop.

## Controlled validation order

1. Wheels raised: use `/sensors`, then place a target separately in front-left,
   front-right, and center. Confirm the matching value changes.
2. Tilt by hand with motor power disconnected. Confirm roll/pitch orientation and
   `TILT_WARNING` beyond 28 degrees.
3. Command `move forward for two seconds at 20 percent`. Bring a target to exactly 10 cm
   of each front sensor and confirm immediate braking.
4. On a clear floor, place an obstacle roughly 30–45 cm ahead. A longer forward command
   should emit `OBSTACLE_DETECTED`, back up, turn toward the clearer LiDAR side, and resume.
5. Test a corridor at low speed and confirm `HEADING_CORRECTION`/`WALL_TOO_CLOSE` events.

The X2's specified near range begins at 0.10 m, so the ToFs and ultrasonic are important
independent coverage at the boundary. No wheel encoders are installed; linear commands
remain duration-based, not centimeter-accurate.

## Configuration

Copy `.env.example` to `.env` inside the imported app and set private keys. Useful optional
settings are `CAMERA_INDEX`, stable `MIC_DEVICE`/`OUTPUT_DEVICE` names, and `LIDAR_PORT`.
The 10 cm emergency thresholds and sensor pin map are intentionally fixed in code.

## Tests

```powershell
python -m unittest discover -v
```

Desktop tests mock Bridge, LiDAR, camera, audio, and network operations. The sketch must be
compiled on UNO Q through Arduino App Lab because the local PC does not include the UNO Q
Zephyr board core.
